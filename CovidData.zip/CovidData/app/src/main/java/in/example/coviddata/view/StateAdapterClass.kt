package `in`.example.coviddata.view

import `in`.example.coviddata.databinding.StatesListItemBinding
import `in`.example.coviddata.model.StatewiseItem
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class StateAdapterClass (private val list: List<StatewiseItem?>?): RecyclerView.Adapter<StateAdapterClass.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val binding = StatesListItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        with(holder){
            mBinding.tvID.text = list!![position]!!.id.toString()
            mBinding.tvFirstName.text = list[position]!!.firstName
            mBinding.tvLastName.text = list[position]!!.lastName
            mBinding.tvEmail.text = list[position]!!.email

        }
    }

    override fun getItemCount(): Int {
        return list!!.size
    }

    inner class ViewHolder(private val mBinding: StatesListItemBinding): RecyclerView.ViewHolder(mBinding.root)
}