package `in`.example.coviddata.view

import `in`.example.coviddata.R
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.google.android.material.tabs.TabLayout
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var tab_viewpager = findViewById<ViewPager>(R.id.view_pager)
        var tab_tablayout = findViewById<TabLayout>(R.id.tabs)

        setupViewPager(tab_viewpager)

        tab_tablayout.setupWithViewPager(tab_viewpager)
    }

    private fun setupViewPager(viewpager: ViewPager) {
        var adapter = ViewPagerAdapter(supportFragmentManager)

        adapter.addFragment(CasesFragment(), "Cases")
        adapter.addFragment(StatesFragment(), "States")
        adapter.addFragment(TestsFragment(), "Tests")

        viewpager.adapter = adapter
    }

    class ViewPagerAdapter : FragmentPagerAdapter {


        private var fragmentList1: ArrayList<Fragment> = ArrayList()
        private var fragmentTitleList1: ArrayList<String> = ArrayList()


        constructor(supportFragmentManager: FragmentManager)
                : super(supportFragmentManager)


        override fun getItem(position: Int): Fragment {
            return fragmentList1[position]
        }


        @Nullable
        override fun getPageTitle(position: Int): CharSequence {
            return fragmentTitleList1[position]
        }


        override fun getCount(): Int {
            return fragmentList1.size
        }


        fun addFragment(fragment: Fragment, title: String) {
            fragmentList1.add(fragment)
            fragmentTitleList1.add(title)
        }
    }
}